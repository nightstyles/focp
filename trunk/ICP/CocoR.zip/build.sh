#!/bin/sh

g++ *.cpp -o Coco -g -Wall

